﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using btl.generic;

public partial class PPGA : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    SqlConnection con1 = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
    protected void UserGrid_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand adp;
        adp = new SqlCommand("select distinct * from diagnosis", con);
        SqlDataReader dr = adp.ExecuteReader();
        while (dr.Read())
        {
            string pid = dr[0].ToString();
            string candidate_agedia = dr[2].ToString() + "@" + dr[6].ToString();
            string candidate_Symp = dr[4].ToString() + "@" + dr[5].ToString() + "@" + dr[6].ToString();
            string candidate_Symp_act = dr[4].ToString() + "@" + dr[5].ToString() + "@" + dr[8].ToString();

            con1.Open();
            SqlCommand cmd = new SqlCommand("insert into tdb values('"+pid +"','"+ candidate_agedia + "','" + candidate_Symp  + "','" + candidate_Symp_act  + "')", con1);
            cmd.ExecuteNonQuery();
            con1.Close();

        }

        con.Close();
      

    }
    public void ug0()
    {

        con.Open();
        SqlDataAdapter adp = new SqlDataAdapter();
        adp = new SqlDataAdapter("select candidate_symp as attribute,count(candidate_symp) as freq from tdb group by candidate_symp having(count(candidate_symp)>1)", con);
        DataSet ds;
        ds = new DataSet();
        adp.Fill(ds, "splitter");
        UserGrid.DataSource = ds.Tables[0];
        UserGrid.DataBind();
        con.Close();

    }

        public void ug1()
    {

        con.Open();
        SqlDataAdapter adp = new SqlDataAdapter();
        adp = new SqlDataAdapter("select candidate_symp_act as attribute,count(candidate_symp_act) as freq from tdb group by candidate_symp_act having(count(candidate_symp_act)>1)", con);
        DataSet ds;
        ds = new DataSet();
        adp.Fill(ds, "splitter");
        UserGrid0.DataSource = ds.Tables[0];
        UserGrid0.DataBind();
        con.Close();

    }

        public void ug2()
        {

            con.Open();
            SqlDataAdapter adp = new SqlDataAdapter();
            adp = new SqlDataAdapter("select candidate_agedia as attribute,count(candidate_agedia) as freq from tdb group by candidate_agedia having(count(candidate_agedia)>1)", con);
            DataSet ds;
            ds = new DataSet();
            adp.Fill(ds, "splitter");
            UserGrid1.DataSource = ds.Tables[0];
            UserGrid1.DataBind();
            con.Close();

        }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select distinct * from sensitive order by fitness_value desc",con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            string strans = dr[0].ToString();
            ListBox3.Items.Add(strans);
            con1.Open();
            SqlCommand cmm = new SqlCommand("select distinct candidate_symp from tdb where candidate_symp like '%" + strans + "%' or candidate_symp like '" + strans + "%'", con1);
            SqlDataReader dr1 = cmm.ExecuteReader();
            int i = 0;
            while (dr1.Read())
            {
                string trans = dr1[0].ToString();
                ListBox4.Items.Add(trans);
                i++;
            }
            con1.Close();
           
            con1.Open();
            SqlCommand cmdd = new SqlCommand("insert into ga values('"+strans +"',"+ i + ")", con1);
            cmdd.ExecuteNonQuery();

            con1.Close();
        }
        con.Close();

        con1.Open();
        SqlCommand cmmo = new SqlCommand("select distinct * from ga where t_count=(select min(t_count) from ga)", con1);
        SqlDataReader dro = cmmo.ExecuteReader();
        string a = "";
        while (dro.Read())
        {
            a = dro[0].ToString() + "-" + dro[1].ToString();

            
        }
        TextBox1.Text = a;
        Random rnd = new Random();
        double cr = rnd.Next(0, 1);
        Random rnd1 = new Random();
        double mu = rnd1.Next(0, 1);
        genetic(cr, mu);

    }
    public static double theActualFunction(double[] values)
    {
        if (values.GetLength(0) != 2)
            throw new ArgumentOutOfRangeException("should only have 2 args");

        double x = values[0];
        double y = values[1];
        double n = 9;  //  should be an int, but I don't want to waste time casting.

        double f1 = Math.Pow(15 * x * y * (1 - x) * (1 - y) * Math.Sin(n * Math.PI * x) * Math.Sin(n * Math.PI * y), 2);
        return f1;
    }
    private void genetic(double d1, double d2)
    {


        //  GA ga = new GA(0.8, 0.05, 100, 2000, 2);
        GA ga = new GA(d1, d2, 10, 20, 2);

        ga.FitnessFunction = new GAFunction(theActualFunction);

        //ga.FitnessFile = @"H:\fitness.csv";
        ga.Elitism = true;
        ga.Go();

        double[] values;
        double fitness;
        ga.GetBest(out values, out fitness);
        // System.Console.WriteLine("Best ({0}):"+ fitness);
       ListBox1.Items.Add("Best Fit  :  " + fitness);
        for (int i = 0; i < values.Length; i++)
            // System.Console.WriteLine("{0} ", values[i]);
            ListBox1.Items.Add("- " + values[i] + Environment.NewLine);
        ga.GetWorst(out values, out fitness);
        // System.Console.WriteLine("\nWorst ({0}):", fitness);
        ListBox2.Items.Add("Worst  : " + fitness);

        for (int i = 0; i < values.Length; i++)
            // System.Console.WriteLine("{0} ", values[i]);
            ListBox2.Items.Add(" - " + values[i] + Environment.NewLine);

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        ug0();
        ug1();
        ug2();
    }
}
