﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Session["type"] = "Admin";
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session["type"] = "User";
        Response.Redirect("Login.aspx");

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Session["type"] = "doc";
        Response.Redirect("Login.aspx");

    }
}
