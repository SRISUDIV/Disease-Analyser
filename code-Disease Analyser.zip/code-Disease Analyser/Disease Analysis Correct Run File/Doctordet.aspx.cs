﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class Doctordet : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = Session["docid"].ToString();
        if (IsPostBack != true)
        {
            docdet();
        }
        txtdoc_id.Enabled = false;
        txtdoc_name.Enabled = false;
        txthospname.Enabled = false;
        txtdoc_spec.Enabled = false;
        txtdoc_time.Enabled = true;
        txthosp_ph.Enabled = true;
        txthosp_email.Enabled = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("update doctor set doc_name='" + txtdoc_name.Text + "',hosp_name='" + txthospname.Text + "',doc_spec='" + txtdoc_spec.Text + "',doc_time='" + txtdoc_time.Text + "',doc_ph='" + txthosp_ph.Text + "',doc_email='" + txthosp_email.Text + "' where doc_id='" + txtdoc_id.Text + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Doctor Details Updated Successfully')</script>");
        con.Close();
    }
    private void docdet()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from doctor where doc_id='" + Label1.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txtdoc_id.Text = (dr[0].ToString());
            txtdoc_name.Text = (dr[1].ToString());
            txthospname.Text = (dr[2].ToString());
            txtdoc_spec.Text = (dr[3].ToString());
            txtdoc_time.Text = (dr[4].ToString());
            txthosp_ph.Text = (dr[5].ToString());
            txthosp_email.Text = (dr[6].ToString());
        }
    }
}