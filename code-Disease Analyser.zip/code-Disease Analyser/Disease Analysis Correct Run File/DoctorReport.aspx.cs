﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class DoctorReport : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack != true)
        {
            disease();
        }
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from diagnosis where doctorsearch='"+DropDownList1.Text +"'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        System.Data.DataSet ds = new System.Data.DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds.Tables[0];
        GridView1.DataBind();
        con.Close();
    }
    private void disease()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select distinct(doctorsearch) from diagnosis ", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DropDownList1.Items.Add(dr[0].ToString());

        }
    }
}