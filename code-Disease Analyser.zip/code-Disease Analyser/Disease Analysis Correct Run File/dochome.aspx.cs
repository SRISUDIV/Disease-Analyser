﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

public partial class dochome : System.Web.UI.Page
{
    DataAccess db = new DataAccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string docid = Session["docid"].ToString();
            //  db.DBDataAdapter("select appoinment.patientid,appoinment.adate,patientinfo.patient_name,patientinfo.pat_address,patientinfo.pat_phone,patientinfo.pat_email from appoinment INNER JOIN patientinfo ON appoinment.patientid=patientinfo.patient_id where appoinment.docid='" + docid + "'", GridView1);
            db.DBDataAdapter("select a.ano,a.patientid,a.adate,b.patient_name,b.pat_address,b.pat_phone,b.pat_email,c.doc_time from appoinment a, patientinfo b,doctor c where a.patientid=b.patient_id and a.docid=c.doc_id and a.docid='" + docid + "' and a.docstatus!='success'", GridView1);

            //select appoinment.adate,patientinfo.patient_name,patientinfo.pat_address,patientinfo.pat_phone,patientinfo.pat_email from appoinment INNER JOIN patientinfo ON appoinment.patientid=patientinfo.patient_id where appoinment.docid='1'

        }
    }
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    public void mail(string rid,string adate,string atime,string pname)
    {
         string docid = Session["docid"].ToString();
        string email = rid;
        string pwd;
        Random rp = new Random();
        MailMessage msg = new MailMessage();
        msg.To.Add(email);
        msg.From = new MailAddress("hasidata@gmail.com");
        msg.Subject = "Appoinment Confirmation mail" ;
        pwd = rp.Next(11111, 99999).ToString();
        msg.Body = "HI,"+pname+" .. your appoinment confirmed on "+adate +" and time is "+ atime ;
       

        SmtpClient cli = new SmtpClient("smtp.gmail.com", 587);
        cli.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential("hasidata@gmail.com", "hasi@12345");
        cli.Credentials = nc;
        cli.Send(msg);
    
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string retnval = "";

       
           for (int i = 0; i < GridView1.Rows.Count; i++)
           {
               string ano = ((Label)GridView1.Rows[i].FindControl("ano")).Text;
               string patientid = ((Label)GridView1.Rows[i].FindControl("patientid")).Text;
               string patientname = ((Label)GridView1.Rows[i].FindControl("patientname")).Text;
               string adate ="";
               try
               {
                 adate  = ((Label)GridView1.Rows[i].FindControl("adate")).Text;
               }
               catch (Exception ex)
               {
                    adate = DateTime.Now.ToShortDateString();
               
               }
               string pname = ((Label)GridView1.Rows[i].FindControl("datereq")).Text;
               string paddress = ((Label)GridView1.Rows[i].FindControl("paddress")).Text;
               string pphone = ((Label)GridView1.Rows[i].FindControl("pph")).Text;
               string pemail = ((Label)GridView1.Rows[i].FindControl("pemail")).Text;
               string atime1 = ((TextBox )GridView1.Rows[i].FindControl("txttime")).Text;

               string astatus = "success";
               if (atime1 != "")
               {                                    
                     
                       string upamz = "update appoinment set  atime='" + atime1 + "',docstatus='" + astatus  + "' where ano=" + Convert.ToInt32(ano) + " ";
                       con.Open();
                     SqlCommand   cmd = new SqlCommand(upamz, con);
                       cmd.ExecuteNonQuery();
                       Response.Write("<script>alert('Appoinment Added Successfully')</script>");
                       con.Close();
                       try
                       {
                           mail(pemail, adate, atime1,patientname );

                       }
                       catch (Exception ex)
                       { }
           }
       }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
   
    protected void GridView1_RowCommand(object sender,GridViewCommandEventArgs e)
    {
        if (e.CommandName == "submit")
        {
            // Retrieve the row index stored in the 
            // CommandArgument property.
            int index = Convert.ToInt32(e.CommandArgument);

            // Retrieve the row that contains the button 
            // from the Rows collection.
            GridViewRow row = GridView1.Rows[index];

            // Add code here to add the item to the shopping cart.
        }

    }
   
}
