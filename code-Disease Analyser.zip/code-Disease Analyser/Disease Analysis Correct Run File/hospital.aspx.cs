﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class hospital : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
      
        db.DBDataAdapter("select * from hospital", gv);

    }
    DataAccess db = new DataAccess();
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into hospital values ('"+txthospid.Text +"','"+ txthospname.Text+"','" + txthospspec.Text+"','" + txthospadd.Text+"','" + txthosp_ph.Text+"')", con);
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "inserted successfully";
        con.Close();
        clear();
        //dbcall();
        Response.Redirect(Request.Url.AbsoluteUri);
    }

    public void dbcall()
    {
        db.DBDataAdapter("select * from hospital", gv);
    
    }
    public void clear()
    {
      
        txthospname.Text = "";
        txthospspec.Text="";
        txthospadd.Text="";
        txthosp_ph.Text = "";
        Label1.Text = "";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("symptom_add.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("disease.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("hospital.aspx");
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctors.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("reports.aspx");
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("update hospital set hosp_name='" + txthospname.Text + "',hosp_spec='" + txthospspec.Text + "',hosp_add='" + txthospadd.Text + "',hosp_ph='" + txthosp_ph.Text + "' where hosp_id ='" + txthospid.Text + "'", con);
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "Updated successfully";
        con.Close();

    }
    private void hid()
    {
        string HospitalID = "HOS";
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from hospital", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        txthospid.Text = HospitalID+count.ToString();
        con.Close();
    }
    protected void LinkButton8_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Upload.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("delete from hospital where hosp_id='" + txthospid.Text + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Hospital Details Deleted Successfully')</script>");
        con.Close();
            
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        hid();
    }
}
