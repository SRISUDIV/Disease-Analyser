﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class disease : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
       
        db.DBDataAdapter("select * from disease", gv);
        disp();
       // db.DBDataAdapter("select * from symptoms", gv);
        //DropDownList1.Items.Clear();
        //db.DBReaderOpen("select sympname,img_name from symptoms ");
        //while (db.dr.Read())
        //{
        //    //
        //    DropDownList1.Items.Add(db.dr[0].ToString());

        //}
    }
    public void disp()
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
        con.Open();

        SqlCommand cmd = new SqlCommand("select * from symptoms", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {


            CheckBox  lbNoImg = new CheckBox ();
            //CheckBox lbNoImg = new CheckBox();
            lbNoImg.Text = dr[1].ToString();
            lbNoImg.Font.Name = "Verdana";
            lbNoImg.Font.Size = FontUnit.Small;

            PlaceHolder1.Controls.Add(lbNoImg);
            Image mm = new Image();
            mm.Height = 100;
            mm.Width = 100;
            mm.ImageUrl = "~/symps/" + dr[3].ToString();

            //mm.ImageUrl = (Server.MapPath("sample.jpeg"));
            PlaceHolder1.Controls.Add(mm);

        }
        con.Close();

    }
    DataAccess db = new DataAccess();
    protected void Button1_Click(object sender, EventArgs e)
    {
        string disea="";
        foreach (CheckBox chk in PlaceHolder1.Controls.OfType<CheckBox>())
        {
            if (chk.Checked)
            {
                disea = disea + "," + chk.Text;

            }
        }


        SqlCommand cmd = new SqlCommand("insert into disease values ('" + txtdisease_id.Text + "','" + txtdis_name.Text + "','" + txttype.Text + "','" + txtdesc.Text + "','" + disea + "')", con);
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "inserted successfully";
        con.Close();
        clear();
       
        //dbcall();
    }

    public void dbcall()
    {
        db.DBDataAdapter("select * from disease", gv);
    
    }
    public void clear()
    {
        txtdisease_id.Text = "";
        txtdis_name.Text = "";
        txttype.Text="";
        txtdesc.Text="";
       
        Label1.Text = "";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("symptom_add.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("disease.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("hospital.aspx");
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctors.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("reports.aspx");
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    private void sid()
    {

        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from disease", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        txtdisease_id.Text = count.ToString();
        con.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("delete from disease where dis_id='" + txtdisease_id.Text + "'", con);
        cmd.ExecuteNonQuery();
        Response.Write ("<script>alert('Disease Details Deleted Successfully')</script>");
        con.Close ();
            
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        sid();
    }
}
