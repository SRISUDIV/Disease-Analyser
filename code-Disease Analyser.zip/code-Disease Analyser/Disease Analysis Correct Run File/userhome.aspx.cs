﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class userhome : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["uid"].ToString();
        pname();
    }
    private void pname()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select patient_name from patient where patient_id='" + Label2.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            Label1.Text = (dr[0].ToString());
        }
        dr.Close();
        con.Close();
    }
}
