﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class symptom_add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Random rnd = new Random();
        int j = rnd.Next(0, 100);
        TextBox1.Text = j.ToString();
        disp();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        //TextBox2.Text = imgUpload.FileName;

        SqlConnection connection = null;
        try
        
        {
            FileUpload img1 = (FileUpload)img;
            Byte[] imgByte = null;
            if (img1.HasFile && img1.PostedFile != null)
            {

                HttpPostedFile File = img1.PostedFile;

                imgByte = new Byte[File.ContentLength];

                File.InputStream.Read(imgByte, 0, File.ContentLength);
            }
            
             string myMap = MapPath("~/").ToLower();
             string ImageName = img.PostedFile.FileName;
                // UploadUserPhoto.PostedFile.FileName;

             string ImageSaveURL = myMap + "symps/" + ImageName;
             img.PostedFile.SaveAs(ImageSaveURL);
        
           
            // getcolor(foo,1, 1, 10, 10, rgbArray, 0, 10);
            // foo.RGB(1, 1, 10, 10, rgbArray, 0, 10);
             //int s = CountImageColors(ImageName );
            // txtdes.Text = s.ToString();
      

            // uplTheFile.PostedFile.SaveAs(ImageSaveURL);
            connection = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

            connection.Open();
            string sql = "INSERT INTO symptoms VALUES(@sympid,@sympname,@sympimg,@img_name)";


            SqlCommand cmd1 = new SqlCommand(sql, connection);
            cmd1.Parameters.AddWithValue("@sympid", TextBox1.Text.Trim());
            cmd1.Parameters.AddWithValue("@sympname", TextBox2.Text.Trim());
            cmd1.Parameters.AddWithValue("@sympimg", imgByte);
          
         cmd1.Parameters.AddWithValue("@img_name", ImageName);
            

            int id = Convert.ToInt32(cmd1.ExecuteNonQuery());
           // lblResult.Text = String.Format("Image ID is {0}", id);

            disp();
        }

        catch (Exception enn)
        {
            Response.Write("<script language='javascript' type='text/javascript'>alert('enn');</script>");
        }
        finally
        {
            connection.Close();
            TextBox2.Text = "";

        }
        
        
        
    }

    public void disp()
    {
       SqlConnection  con= new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
       con.Open();

       SqlCommand cmd = new SqlCommand("select * from symptoms", con);
       SqlDataReader dr = cmd.ExecuteReader();
       while (dr.Read())
       {

          
               Label lbNoImg = new Label();
               //CheckBox lbNoImg = new CheckBox();
               lbNoImg.Text = dr[1].ToString();
               lbNoImg.Font.Name = "Verdana";
               lbNoImg.Font.Size = FontUnit.Small;
               PlaceHolder1.Controls.Add(lbNoImg);
               Image mm = new Image();
               mm.Height = 100;
               mm.Width = 100;
               mm.ImageUrl = "~/symps/" + dr[3].ToString();

               //mm.ImageUrl = (Server.MapPath("sample.jpeg"));
               PlaceHolder1.Controls.Add(mm);
          
       }
       con.Close();
    
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("symptom_add.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("disease.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("hospital.aspx");
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctors.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("reports.aspx");
    }




    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}
