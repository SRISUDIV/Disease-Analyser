﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Default3 : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        pid();
    }
    

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("insert into patient values ('" + TextBox1.Text + "','"+TextBox4.Text +"','" + TextBox3.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            Label1.Text = "inserted successfully";
            con.Close();
           Session["uid"] = TextBox1.Text;
           Session["Ruid"] = "";
           // TextBox1.Text = "";
           // TextBox2.Text = "";
            Response.Redirect("patient_det.aspx");
        }
        catch (Exception ex)
        {
        
        }

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        if (System.Text.RegularExpressions.Regex.IsMatch(TextBox1.Text, "[^0-9]"))
        {
            // MessageBox.Show("Please enter only numbers.");
            Label3.Text = "Please enter only numbers.";
            TextBox1.Text.Remove(TextBox1.Text.Length - 1);
        }
        else
        {
            Label3.Text = "";
        }
    }
    private void pid()
    {
        String PatientID = "PT";
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from patient", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        TextBox1.Text = PatientID+count.ToString();
        con.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
}
