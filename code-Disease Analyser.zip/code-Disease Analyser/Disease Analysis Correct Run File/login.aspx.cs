﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class login : System.Web.UI.Page
{
    string utype;
    protected void Page_Load(object sender, EventArgs e)
    {
        utype = Session["type"].ToString();
          if (utype == "Admin")
        {

            LinkButton4.Visible = true;
        }
          else if ((utype == "User"))
          {
              LinkButton4.Visible = true;
          }
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session["type"] = "User";
        Response.Redirect("Login.aspx");

    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Session["type"] = "Admin";
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
       
        Response.Redirect("patient.aspx");

    }
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        if (utype == "Admin")
        {
            if ((Login1.UserName == "Admin") && (Login1.Password == "Admin"))
            {
                Response.Redirect("hospital.aspx");
            }
            LinkButton4.Visible = false;
        }
        else if((utype == "User"))
        {
            con.Open();
            SqlCommand cmm=new SqlCommand("select * from patient where patient_id='"+Login1.UserName+"' and Patient_pass='"+Login1.Password +"'",con );
            SqlDataReader dr=cmm.ExecuteReader();
            if (dr.Read())
            {
                Session["uid"] = Login1.UserName.ToString();
                //Session["Ruid"] = Login1.UserName.ToString();
                uname();
                Response.Redirect("userhome.aspx");
            }
            else 
            { 
            
            }
            LinkButton4.Visible = true;
        
        }
        else if ((utype == "doc"))
        {
            con.Open();
            SqlCommand cmm = new SqlCommand("select * from doctor where doc_id='" + Login1.UserName + "' and doc_name='" + Login1.Password + "'", con);
            SqlDataReader dr = cmm.ExecuteReader();
            if (dr.Read())
            {
                Session["docid"] = Login1.UserName.ToString();
                Session["docname"] = Login1.UserName.ToString();
                Response.Redirect("dochome.aspx");
            }
            else
            {

            }
            LinkButton4.Visible = true;

        }
        
    }
    private void uname()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select patient_name from patient where patient_id='" + Login1.UserName.ToString () + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            Session["cid"] = dr[0].ToString();
        }
        dr.Close();
        con.Close();
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Session["type"] = "doc";
        Response.Redirect("login.aspx");
    }
}
