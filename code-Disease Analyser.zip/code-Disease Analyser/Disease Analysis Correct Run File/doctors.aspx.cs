﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
public partial class doctors : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList2.Items.Clear();
            DropDownList2.Items.Add("General Doctor");
            DropDownList2.Items.Add("Gynecologist");
            DropDownList2.Items.Add("Pediatrician");
            DropDownList2.Items.Add("Ophthalmologist");
            DropDownList2.Items.Add("Dermatologist");
            DropDownList2.Items.Add("ENT doctor");
            DropDownList2.Items.Add("orthopedic");
            DropDownList2.Items.Add("Cardiologist");
            DropDownList2.Items.Add("Neurologist");
            DropDownList2.Items.Add("Dentist");
            DropDownList2.Items.Add("Urologist");
            DropDownList2.Items.Add("Psychiatrist");
            DropDownList2.Items.Add("Pathologistt");
            DropDownList2.Items.Add("Radiologists");
            DropDownList2.Items.Add("Anesthesiologist");
            DropDownList2.Items.Add("General Surgeon");
            DropDownList2.Items.Add("Oncologist");
            DropDownList2.Items.Add("Nephrologist");
            DropDownList2.Items.Add("Endocrinologist");
            DropDownList2.Items.Add("Gastrologist");
            DropDownList1.Items.Clear();
            db.DBDataAdapter("select * from doctor", gv);
            //DropDownList1.Items.Clear();
            db.DBReaderOpen("select distinct hosp_name from hospital ");
            while (db.dr.Read())
            {
                //
                DropDownList1.Items.Add(db.dr[0].ToString());

            }
        }
       
    }
    DataAccess db = new DataAccess();
    protected void Button1_Click(object sender, EventArgs e)
    {
        txthospname.Text = DropDownList1.Text;
        txtdoc_spec.Text = DropDownList2.Text;
        SqlCommand cmd = new SqlCommand("insert into doctor values ('" + txtdoc_id.Text + "','" + txtdoc_name.Text+ "','" + txthospname.Text + "','" + txtdoc_spec.Text + "','" + txtdoc_time.Text + "','" + txthosp_ph.Text + "','"+txthosp_email.Text +"')", con);
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "inserted successfully";
        email();
        con.Close();
        clear();
        //dbcall();
        //Response.Redirect(Request.Url.AbsoluteUri);
    }

    public void dbcall()
    {
        //db.DBDataAdapter("select * from doctor", gv);
    
    }
    public void clear()
    {
        txtdoc_id.Text = "";
        txthospname.Text = "";
        txtdoc_spec.Text="";
        txtdoc_time.Text="";
        txthosp_ph.Text = "";
        Label1.Text = "";
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("symptom_add.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("disease.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("hospital.aspx");
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("doctors.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("reports.aspx");
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void LinkButton7_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (txtdoc_id.Text == "")
        {
            Label1.Text = "insert doctor id to delete..";

        }
        else
        {
            SqlCommand cmd = new SqlCommand("delete from doctor where doc_id='" + txtdoc_id.Text + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            Label1.Text = "Deleted successfully";
            con.Close();
           // dbcall();
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("update doctor set doc_name='" + txtdoc_name.Text + "',hosp_name='" + txthospname.Text + "',doc_spec='" + txtdoc_spec.Text + "',doc_time='" + txtdoc_time.Text + "',doc_ph='" + txthosp_ph.Text + "' where doc_id='" + txtdoc_id.Text + "'", con);

       // SqlCommand cmd = new SqlCommand("update doctor set doc_name='" + txthospname.Text + "',hosp_spec='" + txthospspec.Text + "',hosp_add='" + txthospadd.Text + "',hosp_ph='" + txthosp_ph.Text + "' where hosp_id ='" + txthospid.Text + "'", con);
        con.Open();
        cmd.ExecuteNonQuery();
        Label1.Text = "Updated successfully";
        con.Close();
    }
    private void email()
    {
        try
        {
            con.Close();
            con.Open();
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            System.Net.NetworkCredential cred = new System.Net.NetworkCredential("hasidata@gmail.com", "hasi@12345");
            mail.To.Add(txthosp_email.Text);
            mail.Subject = "Admin Add You in the Diease Diagnose Website";
            mail.From = new System.Net.Mail.MailAddress("hasidata@gmail.com");
            mail.IsBodyHtml = true; // Aceptamos HTML
            mail.Body = "Dear Doctor:'" + txtdoc_name.Text  + "',Your login id: '" + txtdoc_id.Text  + "',password:'" + txtdoc_name.Text  + "' is use to login into the website. Thank You";
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient("smtp.gmail.com");
            smtp.UseDefaultCredentials = false;
            smtp.EnableSsl = true;
            smtp.Credentials = cred; //asignamos la credencial
            smtp.Send(mail);
            Response.Write("<script>alert(' Mail Send Successfully)</script>");
            con.Close();
        }
        catch (Exception)
        {

        }
    }
    private void docid()
    {
        string DoctorID = "DOC";
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from doctor", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        txtdoc_id.Text = DoctorID+count.ToString();
        con.Close();
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        docid();
    }
}
