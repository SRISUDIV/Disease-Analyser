﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class dappoinment : System.Web.UI.Page
{
    DataAccess db = new DataAccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            string diesases = Session["docid"].ToString();
            if (Session["docid"].ToString() != null)
            {
                if (diesases != "")
                {
                    db.DBDataAdapter("select ano as appoinment_no,patientid,adate,docname,hospname,atime,docstatus as appoinment_status from appoinment where docid= '" + Session["docid"].ToString() + "'", gv);
                    if (gv.Rows.Count==0)
                    {
                    }
                    else
                    {
                        db.DBDataAdapter("select ano as appoinment_no,patientid,adate,docname,hospname,atime,docstatus as appoinment_status from appoinment where docid= '" + Session["docid"].ToString() + "'", gv);

                    }

                }
                else
                {
                    db.DBDataAdapter("select ano as appoinment_no,patientid,adate,docname,hospname,atime,docstatus as appoinment_status from appoinment where docid= '" + Session["docid"].ToString() + "'", gv);

                }
            }
        }
        catch (Exception ex)
        {
          //  db.DBDataAdapter("select distinct * from hospital ", gv);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
      
    }
}
