﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Xml;

public partial class hopsearch : System.Web.UI.Page
{

    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    DataAccess db = new DataAccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = Session["pid"].ToString();
        if (IsPostBack != true)
        {
            hname();
        }
        try
        {
            string diesases = Session["dise"].ToString();
            string hname= System.Net.Dns.GetHostName().ToString();
            Label2.Text =System.Net.Dns.GetHostByName(hname).AddressList[0].ToString(); 
            if (Session["dise"].ToString() != null)
            {
                if (diesases != "")
                {
                    db.DBDataAdapter("select distinct * from hospital where hosp_spec like '" + Session["dise"].ToString() + "%'", gv);
                    if (gv.Rows.Count==0)
                    {
                    }
                    else
                    {
                        db.DBDataAdapter("select distinct * from hospital ", gv);

                    }

                }
                else
                {
                    db.DBDataAdapter("select distinct * from hospital ", gv);

                }
            }
        }
        catch (Exception ex)
        {
            db.DBDataAdapter("select distinct * from hospital ", gv);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        string hname = System.Net.Dns.GetHostName().ToString();
          string ip  = System.Net.Dns.GetHostByName(hname).AddressList[0].ToString(); 
    
          con.Close();
          con.Open();
          SqlCommand cmd = new SqlCommand("select  * from doctor where hosp_name = '" + DropDownList1.Text + "'", con);
          SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
        {
            Panel pp = new Panel();

            pp.BackColor = System.Drawing.Color.AliceBlue;
            //SqlDataReader dr2 = DB.DBReaderOpen("select disease,count(disease) as sup from temp_score group by disease having (count(disease) >1) order by sup desc");
            TextBox tb1 = new TextBox();
            tb1.TextMode = TextBoxMode.MultiLine;
            tb1.Height = 100;
            tb1.Width = 140;
            tb1.Text = dr[1].ToString() + Environment.NewLine + dr[2].ToString() + Environment.NewLine + dr[3].ToString() + Environment.NewLine + dr[4].ToString() + Environment.NewLine + dr[5].ToString() + Environment.NewLine;

            tb1.BackColor = System.Drawing.Color.AliceBlue;
            LinkButton ll = new LinkButton();
            ll.Text = "get appoinment";
            ll.ID = dr[0].ToString();
            Session["app"] = dr[0].ToString();
            ll.PostBackUrl = "appoinment.aspx?id=" + dr[0].ToString();
            pp.Controls.Add(tb1);
            pp.Controls.Add(ll);
            Panel2.Controls.Add(pp);

        }
            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("update diagnosis set hospitalsearch='" + DropDownList1.Text  + "' where patient_id='" + Label3.Text + "'", con);
            cmd1.ExecuteNonQuery();
            con.Close();

    }
    private void hname()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select hosp_name from hospital ", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while  (dr.Read())
        {

            DropDownList1.Items.Add(dr[0].ToString());

        }

        con.Close();
    }
}
