﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.SqlClient;

public partial class reports : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        //DataAccess db = new DataAccess();
        //db.DBDataAdapter("select distinct ano,patientid,docid,adate,docname,hospname,atime,docstatus from appoinment", GridView1);
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "Hospital")
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from hospital ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            System.Data.DataSet ds = new System.Data.DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            con.Close();
        }
        else if (DropDownList1.Text == "Doctor")
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from doctor ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            System.Data.DataSet ds = new System.Data.DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            con.Close();
        }
        else if (DropDownList1.Text == "Patient")
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from patientinfo ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            System.Data.DataSet ds = new System.Data.DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            con.Close();
        }
        else if (DropDownList1.Text == "Disease")
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from disease ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            System.Data.DataSet ds = new System.Data.DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            con.Close();
        }
        else if (DropDownList1.Text == "Appoinment")
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from appoinment ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            System.Data.DataSet ds = new System.Data.DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            con.Close();
        }
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
      
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {

        
        
      
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("DatewiseReport.aspx");
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("DoctorReport.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("HospitalReport.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("DiseaseReport.aspx");
    }
}