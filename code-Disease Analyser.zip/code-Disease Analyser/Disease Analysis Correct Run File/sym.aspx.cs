﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.IO;

public partial class sym : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = System.DateTime.Now.ToShortDateString();
        disp();
       
        exceltodb();
    }
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    public void symptomsload()
    {
      //  CheckBoxList1.Items.Clear();
        con.Open();

        SqlCommand cmd = new SqlCommand("select distinct * from all_symptoms order by symptoms asc", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            CheckBoxList1.Items.Add(dr[0].ToString());

        }
        con.Close();

    }
    public void disp()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("select * from symptoms", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {


            CheckBox  lbNoImg = new CheckBox ();
            //CheckBox lbNoImg = new CheckBox();
            lbNoImg.ID = "i" + dr[0].ToString();
           // lbNoImg_checkedchanged+=new 
            lbNoImg.Text = dr[1].ToString();
            lbNoImg.Font.Name = "Verdana";
            lbNoImg.Font.Size = FontUnit.Small;
            lbNoImg.CheckedChanged+=new EventHandler(lbNoImg_CheckedChanged);
           // chkList1.CheckedChanged += new EventHandler(CheckBox_CheckedChanged);
            PlaceHolder1.Controls.Add(lbNoImg);
            Image mm = new Image();
            mm.Height = 100;
            mm.Width = 100;
            mm.ImageUrl = "~/symps/" + dr[3].ToString();

            //mm.ImageUrl = (Server.MapPath("sample.jpeg"));
            PlaceHolder1.Controls.Add(mm);

        }
        con.Close();

    }
    string disea = "";
    
    protected void lbNoImg_CheckedChanged(object sender, EventArgs e)
    {
        //Response.Write(((CheckBox)sender).ClientID);
        //disea=
       // disea=((CheckBox)sender).ClientID.ToString();
        //Label1.Text = 
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

        con.Open();

        SqlCommand cmd = new SqlCommand("select * from patientinfo where patient_id='" + TextBox1.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            TextBox2.Text = dr[1].ToString();

            TextBox3.Text = dr[2].ToString();
        }
        con.Close();
    }
    public void diagnosis()
    {

        con.Open();
        SqlCommand cmd = new SqlCommand("insert into diagnosis values('" + TextBox1.Text  + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','"+TextBox7.Text  +"','"+DateTime.Now.ToString()+"','"+Label1.Text +"','Pending','Pending','"+Label2.Text +"')", con);
        cmd.ExecuteNonQuery();
       // Label7.Text = "Diagnosis processing....";
        con.Close();


    }
    private void disease_dia()
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("select * from diagnosis where patient_id='" + TextBox1.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            TextBox2.Text = dr[1].ToString();

            TextBox3.Text = dr[2].ToString();
        }
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        foreach (CheckBox chk in PlaceHolder1.Controls.OfType<CheckBox>())
        {
            if (chk.Checked)
            {
                disea = disea +","+ chk.Text ;

            }
        }

        ANT_classify antclass = new ANT_classify();
        antclass.TrainClassifier(table);
        double c, d, ee, f;

        c = Convert.ToDouble(TextBox3.Text);
        if (TextBox4.Text == "Male")
        {
            TextBox4.Text = "1";
        }
        else if (TextBox4.Text == "Female")
        {
            TextBox4.Text = "2";
        }
        else { TextBox4.Text = "1"; }
        d = Convert.ToDouble(TextBox4.Text);
        ee = Convert.ToDouble(TextBox5.Text);
        f = Convert.ToDouble(TextBox6.Text);
        // Console.WriteLine(classifier.Classify(new double[] { 4, 150, 12 }));

        try
        {

            Label1.Text = "Detected Class is:" + (antclass.Classify(new double[] { c, d, ee, f }));


        }
        catch (Exception ex)
        { }
        diagnosis();
    
    }
    DataTable table = new DataTable();
    private void exceltodb()
    {
        try
        {
            string connstr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source= D:\appoinment.xls;Extended Properties=Excel 8.0";

            // string connstr ="Provider=Microsoft.Jet.Oledb.4.0;Data Source=C:\ds\cldata.xls;Extended Properties=Excel 8.0"/>
            OleDbConnection conn = new OleDbConnection(connstr);
            string strSQL = "SELECT * FROM [Sheet2$]";


            OleDbCommand cmd = new OleDbCommand(strSQL, conn);
            DataSet ds = new DataSet();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(ds);
            //  dataGridView2.DataSource = ds.Tables[0];
            table = ds.Tables[0];
        }
        catch (Exception ex)
        { }
        // dataGridView1.DataBind();

    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox4.Text = DropDownList1.Text;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        foreach (ListItem item in CheckBoxList1.Items )
        {
            if (item.Selected)
            {
                disea =item.Text ;
                ListBox1.Items.Add(disea);
                TextBox7.Text = disea;
            }
            else
            {
               
            }
        }

        //ListBox1.Items.Add(disea);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        symptomsload();
    }
    DataAccess DB = new DataAccess();
    protected void Button4_Click(object sender, EventArgs e)
    {
        DB.DBCmdOpen("delete from temp_score ");


        string resultss="";
        int score;
        for (int i = 0; i < ListBox1.Items.Count; i++)
        {
            string symp = ListBox1.Items[i].ToString();
            symp = symp.Trim();
            con.Open();

            SqlCommand cmd = new SqlCommand("select * from symp_disease where symptom ='" + symp + "' or symptom like '"+ symp +"%'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                resultss =resultss+ "/"+ dr[0].ToString();
                score = Convert.ToInt32(dr[2].ToString());
                DB.DBCmdOpen("insert into temp_score values('" + dr[0].ToString() + "'," + score + ")");
            }
            con.Close();
            

        }
        
       
        
       // Label1.Text = resultss;

        SqlDataReader dr1=DB.DBReaderOpen("select * from temp_score where score=(select max(score) from temp_score)");
        if (dr1.Read())
        {
            SqlDataReader dr2 = DB.DBReaderOpen("select disease,count(disease) as sup from temp_score group by disease having (count(disease) >1) order by sup desc");


            while  (dr2.Read())
            {

                if ((dr1[0].ToString() == "Pregnancy") && (TextBox4.Text == "Female") && (Convert.ToInt32(TextBox3.Text) > 15))
                {

                    Label1.Text = "Pregnancy";
                }
                else if ((dr1[0].ToString() == "Breast Disease") && (TextBox4.Text == "Female") && (Convert.ToInt32(TextBox3.Text) > 12))
                {

                    Label1.Text = "Breast Disease";
                }
                else
                {
                    Label1.Text = dr2[0].ToString();
                    diagnosis();
                }
            }
            Label1.Text = dr1[0].ToString();

        }
        Session["dise"] = Label1.Text;
        Session["pid"] = TextBox1.Text;

        Response.Redirect("support.aspx");

       // string[] dia_dis = Label1.Text.Split('/');

    }
    protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
