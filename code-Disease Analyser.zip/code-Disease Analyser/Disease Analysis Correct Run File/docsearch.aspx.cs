﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class hopsearch : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    DataAccess db = new DataAccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text =Session["pid"].ToString ();
        try
        {
            if (Session["dise"].ToString() != null)
            {
                db.DBDataAdapter("select distinct * from hospital where doc_spec  like '" + Session["dise"].ToString() + "%'", gv);
            }
        }
        catch (Exception ex)
        {
            db.DBDataAdapter("select distinct * from doctor ", gv);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        
        SqlDataReader dr1 = db.DBReaderOpen("select distinct * from doctor where doc_name like '" + TextBox1.Text + "%'  or hosp_name like '" + TextBox1.Text + "%' or doc_spec like '" + TextBox1.Text + "%'");
        while  (dr1.Read())
         {
             Panel pp = new Panel();
            
             pp.BackColor = System.Drawing.Color.AliceBlue;
            //  SqlDataReader dr2 = DB.DBReaderOpen("select disease,count(disease) as sup from temp_score group by disease having (count(disease) >1) order by sup desc");
             TextBox tb = new TextBox();
             tb.TextMode = TextBoxMode.MultiLine;
             tb.Height = 100;
             tb.Width = 140;
             tb.Text = dr1[1].ToString() + Environment.NewLine + dr1[2].ToString() + Environment.NewLine + dr1[3].ToString() + Environment.NewLine + dr1[4].ToString() + Environment.NewLine + dr1[5].ToString() + Environment.NewLine;
            
             //tb.BackColor = System.Drawing.Color.AliceBlue;
             //LinkButton ll = new LinkButton();
             //ll.Text = "get appoinment";
             //ll.ID = dr1[0].ToString();
             //Session["app"] = dr1[0].ToString();
             //ll.PostBackUrl = "appoinment.aspx" ;
             pp.Controls.Add(tb);
             //pp.Controls.Add(ll);
             Panel1.Controls.Add(pp);
             
         }
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("update diagnosis set doctorsearch='" + TextBox1.Text + "' where patient_id='" + Label3.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
    }
}
