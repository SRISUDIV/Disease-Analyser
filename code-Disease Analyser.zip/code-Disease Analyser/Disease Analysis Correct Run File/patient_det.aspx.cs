﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public partial class patient_det : System.Web.UI.Page
{

      SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
      string registered_user="";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            registered_user = Session["Ruid"].ToString();
        }
        catch (Exception ex)
        {
            registered_user = "";
        }

        if ((registered_user != "") && (registered_user != null))
        {
            if ((Session["Ruid"].ToString() =="") && (Session["Ruid"].ToString() == null))
            {

            }
            else{
                TextBox1.Enabled = false;
                TextBox4.Enabled = false;
                Button1.Visible = false;
                Button2.Visible = false;
                user_menu1.Visible = true;

                con.Open();
                SqlCommand cmd = new SqlCommand("select * from patientinfo where patient_id='" + Session["uid"].ToString() + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    TextBox1.Text = dr[1].ToString();
                    TextBox2.Text = dr[2].ToString();
                    TextBox3.Text = dr[3].ToString();
                    TextBox4.Text = dr[4].ToString();
                    TextBox5.Text = dr[5].ToString();
                    TextBox6.Text = dr[6].ToString();

                }
                Label7.Text = "U have already registered..if u want update click on update button..";
                con.Close();
            }
        }
        else {

            user_menu1.Visible = false;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text="";
    }
    public bool phone(string no)
    {
        Regex expr = new Regex(@"^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1}){0,1}9[0-9](\s){0,1}(\-){0,1}(\s){0,1}[1-9]{1}[0-9]{7}$");
        if (expr.IsMatch(no))
        {
            return true;
        }
        else return false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DateTime  birthday = Convert.ToDateTime(TextBox4.Text);

        TimeSpan t = DateTime.Now.Subtract(birthday);
       string age =  t.TotalDays.ToString();
        //int age = (Int32.Parse(DateTime.Today.ToString("MMddYYYY")) - Int32.Parse(birthday.ToString("MMddYYYY"))) / 10000;
       double dd = Convert.ToDouble(age) / 365;
       int age1 = Convert.ToInt32(dd);
        DropDownList1.Items.Clear();
        DropDownList1.Items.Add(age1.ToString());

        Regex validator = new Regex("(3|4|5|6|7|8|9){1}[0-9]{9}");
            string match = validator.Match(TextBox5.Text ).Value.ToString();

            if ((TextBox5.Text != "") && (match.Length == 10))
            {
                //if (phone(TextBox5.Text) == true)
                //{

                    
                //}
                //else
                //{
                //    Label7.Text = "Invalid phone number.....";
                //    TextBox5.Text = "";
                //}
            }
            else
            {
                TextBox5.Text = "";
              Label7.Text = "Invalid phone number.....";

            }

        if((TextBox1.Text=="")||(DropDownList1.Text =="")||(TextBox3.Text=="")||(TextBox4.Text=="")||(TextBox5.Text==""))
        {
            Label7.Text = "Enter all fields.....";
        }
        else{
                    TextBox2.Text = DropDownList1.Text;

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into patientinfo values('" + Session["uid"].ToString() + "','" + TextBox1.Text + "','" + DropDownList1.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    Label7.Text = "Registered Successfully.....";
                    con.Close();

                    Response.Redirect("Login.aspx");
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if ((TextBox1.Text == "") || (TextBox2.Text == "") || (TextBox3.Text == "") || (TextBox4.Text == "") || (TextBox5.Text == ""))
        {
            Label7.Text = "enter all fields....";

        }
        else
        {
              Regex validator = new Regex("(3|4|5|6|7|8|9){1}[0-9]{9}");
            string match = validator.Match(TextBox5.Text ).Value.ToString();

            if ((TextBox5.Text != "") && (match.Length == 10))
            {
                //if (phone(TextBox5.Text) == true)
                //{

                    
                //}
                //else
                //{
                  Label7.Text = "Invalid phone number.....";
                TextBox5.Text = "";
                //}
            }
            else
            {
                TextBox5.Text = "";
              Label7.Text = "Invalid phone number.....";

            }

            if ((TextBox1.Text == "") || (DropDownList1.Text == "") || (TextBox3.Text == "") || (TextBox4.Text == "") || (TextBox5.Text == ""))
            {
                Label7.Text = "Enter all fields.....";
            }
            else
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("update patientinfo set pat_age='" + DropDownList1.Text + "',pat_address='" + TextBox3.Text + "',pat_phone='" + TextBox5.Text + "',pat_email='" + TextBox6.Text + "' where patient_id='" + Session["uid"].ToString() + "'", con);
                cmd.ExecuteNonQuery();
                Label7.Text = "Updated Successfully.....";
                con.Close();
            }
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
        }
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox4.Text = Calendar1.SelectedDate.ToString();
    }
}
