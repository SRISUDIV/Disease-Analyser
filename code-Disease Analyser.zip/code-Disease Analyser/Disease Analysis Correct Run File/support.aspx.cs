﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class support : System.Web.UI.Page
{
    DataAccess db = new DataAccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["dise"].ToString();
        dbcall();
    }
    public void dbcall()
    {
       // db.DBDataAdapter("select symptom,count(symptom) as support from symp_disease group by symptom having(count(symptom)>0) order by support desc", GridView1 );
      //  db.DBDataAdapter("select pat_symps,count(pat_symps) as support from diagnosis where pat_symps!='' group by pat_symps having(count(pat_symps)>0) order by support desc", GridView2);
        db.DBDataAdapter("select * from hospital where hosp_spec='"+Label2.Text +"'", GridView1);
        GridView1.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("PPGA.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (Label2.Text != "")
        {
            Session["dise"] = Label2.Text;
        }
        Response.Redirect("hopsearch.aspx");
    }
}
