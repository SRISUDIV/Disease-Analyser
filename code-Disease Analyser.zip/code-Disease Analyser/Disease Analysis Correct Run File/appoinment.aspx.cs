﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class appoinment : System.Web.UI.Page
{
    int count;

    SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");
    SqlConnection con1 = new SqlConnection(@"Data Source=.;Initial Catalog=appoinment;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        Label2.Text = Session["uid"].ToString();
        pid();
        if (!IsPostBack)
        {
        TextBox1.Text = DateTime.Now.ToShortDateString();
         }
        string docid = Request.QueryString["id"];
        

        con.Open();

        SqlCommand cmd = new SqlCommand("select * from doctor where doc_id='" + docid+ "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        { 
            txtdoc_id.Text = dr[0].ToString();
            txtdoc_name.Text = dr[1].ToString();
            txthospname.Text = dr[2].ToString();
            txtdoc_spec.Text = dr[3].ToString();
            txtdoc_time.Text = dr[4].ToString();
           txthosp_ph.Text  = dr[5].ToString();

      
        }
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();

        SqlCommand cmd = new SqlCommand("select * from appoinment where docid='" + txtdoc_id.Text + "' and adate='" + TextBox1.Text + "' and patientid='" + Session["uid"].ToString() + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Label1.Text = "select different date to get appoinment..";
            
        }
        else
        {

            con1.Open();
            SqlCommand cmd1 = new SqlCommand("insert into appoinment values('"+Label3.Text +"','" + Label2.Text  + "','"+txtdoc_id.Text +"','" + TextBox1.Text + "','" + txtdoc_name.Text + "','" + txthospname.Text + "','0','0','0')", con1);
            cmd1.ExecuteNonQuery();
            Label1.Text = "Appoinment details entered Successfully.....you will receive a confirmation mail";
            con1.Close();


        }
        con.Close();


    }
    private void pid()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from patient", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        Label3.Text  = count.ToString();
        con.Close();
    }
}
